"""Cấu hình chung (NFR03: phiên đăng nhập hết hạn sau 30 phút không hoạt động)."""
import os
from datetime import timedelta

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    # Đổi SECRET_KEY khi triển khai thật (đặt biến môi trường SECRET_KEY)
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-only-change-me")
    DATABASE = os.environ.get("DATABASE", os.path.join(BASE_DIR, "attendance.db"))

    # NFR03: tự đăng xuất sau 30 phút không hoạt động
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=30)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    # Bật True khi chạy HTTPS (NFR03: dữ liệu gửi qua HTTPS)
    SESSION_COOKIE_SECURE = os.environ.get("HTTPS", "0") == "1"

    MIN_PASSWORD_LENGTH = 6
