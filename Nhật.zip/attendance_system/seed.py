"""Tạo tài khoản mẫu để thử: python seed.py"""
from app import create_app
from models.user import User

DEMO = [
    ("admin",    "admin123",    "Quản trị viên",    "Admin",    None),
    ("gv01",     "lecturer123", "Giảng viên A",     "Lecturer", "GV01"),
    ("sv001",    "student123",  "Sinh viên Nguyễn B", "Student", "SV001"),
]

app = create_app()
with app.app_context():
    for username, pw, name, role, ref in DEMO:
        if User.find_by_username(username):
            print(f"Bỏ qua (đã có): {username}")
            continue
        User.create(username, pw, name, role, ref)
        print(f"Đã tạo: {username} / {pw} ({role})")
