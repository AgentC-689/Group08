"""Trang chủ theo vai trò. Đây là điểm để Người 2-5 gắn chức năng của mình vào.

Mỗi trang đã được bảo vệ bằng role_required (phân quyền - NFR04).
"""
from flask import Blueprint, render_template
from utils.security import role_required, current_user

bp = Blueprint("dashboard", __name__, url_prefix="/dashboard")


@bp.route("/admin")
@role_required("Admin")
def admin_home():
    return render_template("dashboard.html", user=current_user(),
                           title="Quản trị viên",
                           menu=["Quản lý tài khoản", "Quản lý sinh viên",
                                 "Quản lý lớp & môn học", "Báo cáo điểm danh"])


@bp.route("/lecturer")
@role_required("Lecturer")
def lecturer_home():
    return render_template("dashboard.html", user=current_user(),
                           title="Giảng viên",
                           menu=["Lớp của tôi", "Tạo phiên điểm danh",
                                 "Điểm danh", "Lịch sử & báo cáo"])


@bp.route("/student")
@role_required("Student")
def student_home():
    return render_template("dashboard.html", user=current_user(),
                           title="Sinh viên",
                           menu=["Check-in", "Lịch sử điểm danh của tôi"])
