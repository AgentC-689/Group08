"""Controller: đăng nhập, đăng xuất, đổi mật khẩu (FR01, FR02, UC01)."""
from flask import (Blueprint, render_template, request, redirect, url_for,
                   session, flash, current_app)

from models.user import verify_credentials
from utils.security import (current_user, home_for, login_required,
                            check_csrf, is_safe_next)

bp = Blueprint("auth", __name__)


@bp.route("/", methods=["GET"])
def index():
    user = current_user()
    return redirect(home_for(user) if user else url_for("auth.login"))


@bp.route("/login", methods=["GET", "POST"])
def login():
    user = current_user()
    if user:
        return redirect(home_for(user))

    if request.method == "POST":
        check_csrf()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        # Alternative flow: thiếu thông tin bắt buộc
        if not username or not password:
            flash("Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.", "error")
            return render_template("login.html", username=username), 400

        user, error = verify_credentials(username, password)
        if error == "locked":
            flash("Tài khoản đã bị khóa. Vui lòng liên hệ quản trị viên.", "error")
            return render_template("login.html", username=username), 403
        if error:
            flash("Sai tên đăng nhập hoặc mật khẩu.", "error")
            return render_template("login.html", username=username), 401

        # Thành công: tạo phiên mới (chống session fixation)
        session.clear()
        session.permanent = True            # áp dụng timeout 30 phút
        session["user_id"] = user.id
        user.touch_last_login()

        nxt = request.args.get("next")
        if is_safe_next(nxt):
            return redirect(nxt)
        return redirect(home_for(user))

    return render_template("login.html", username="")


@bp.route("/logout", methods=["POST"])
def logout():
    check_csrf()
    session.clear()
    flash("Bạn đã đăng xuất.", "info")
    return redirect(url_for("auth.login"))


@bp.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    user = current_user()
    if request.method == "POST":
        check_csrf()
        old = request.form.get("old_password", "")
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        min_len = current_app.config["MIN_PASSWORD_LENGTH"]

        if not user.check_password(old):
            flash("Mật khẩu hiện tại không đúng.", "error")
        elif len(new) < min_len:
            flash(f"Mật khẩu mới phải có ít nhất {min_len} ký tự.", "error")
        elif new != confirm:
            flash("Mật khẩu xác nhận không khớp.", "error")
        elif new == old:
            flash("Mật khẩu mới phải khác mật khẩu cũ.", "error")
        else:
            user.change_password(new)
            flash("Đổi mật khẩu thành công.", "success")
            return redirect(home_for(user))
        return render_template("change_password.html"), 400

    return render_template("change_password.html")
