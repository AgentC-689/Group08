"""Phân quyền (NFR04) + CSRF + kiểm tra redirect an toàn.

Người 2-5 chỉ cần dùng 2 decorator:

    from utils.security import login_required, role_required

    @bp.route("/students")
    @role_required("Admin")
    def students(): ...

    @bp.route("/attendance")
    @role_required("Lecturer", "Admin")
    def attendance(): ...
"""
import secrets
from functools import wraps
from urllib.parse import urlparse, urljoin

from flask import session, redirect, url_for, request, abort, g

from models.user import User

# Trang chủ theo vai trò (UC01 bước 4: mở trang chính theo role)
ROLE_HOME = {
    "Admin": "dashboard.admin_home",
    "Lecturer": "dashboard.lecturer_home",
    "Student": "dashboard.student_home",
}


def current_user():
    """Lấy user đang đăng nhập (cache trong g cho mỗi request)."""
    if "user" not in g:
        uid = session.get("user_id")
        g.user = User.find_by_id(uid) if uid else None
        # Tài khoản bị xóa hoặc bị khóa khi đang đăng nhập -> vô hiệu phiên
        if uid and (g.user is None or g.user.is_locked):
            session.clear()
            g.user = None
    return g.user


def home_for(user):
    return url_for(ROLE_HOME[user.role])


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if current_user() is None:
            return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
        return view(*args, **kwargs)
    return wrapped


def role_required(*roles):
    """Chỉ cho phép các vai trò trong `roles`; sai quyền -> 403."""
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            user = current_user()
            if user is None:
                return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
            if user.role not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


# ---------- CSRF ----------
def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


def check_csrf():
    sent = request.form.get("_csrf", "")
    if not sent or not secrets.compare_digest(sent, session.get("_csrf", "")):
        abort(400, "CSRF token không hợp lệ")


# ---------- redirect an toàn ----------
def is_safe_next(target):
    if not target:
        return False
    ref = urlparse(request.host_url)
    test = urlparse(urljoin(request.host_url, target))
    return test.scheme in ("http", "https") and ref.netloc == test.netloc
