"""Model: tài khoản người dùng (tầng Model trong MVC)."""
from werkzeug.security import generate_password_hash, check_password_hash
from db import get_db

ROLES = ("Admin", "Lecturer", "Student")

# Hash giả để kiểm tra khi username không tồn tại -> thời gian phản hồi giống nhau
_DUMMY_HASH = generate_password_hash("dummy-password")


class User:
    def __init__(self, row):
        self.id = row["UserID"]
        self.username = row["Username"]
        self.password_hash = row["PasswordHash"]
        self.full_name = row["FullName"]
        self.role = row["Role"]
        self.ref_id = row["RefID"]
        self.is_locked = bool(row["IsLocked"])

    # ---------- truy vấn ----------
    @staticmethod
    def find_by_username(username):
        row = get_db().execute(
            "SELECT * FROM Users WHERE Username = ?", (username,)
        ).fetchone()
        return User(row) if row else None

    @staticmethod
    def find_by_id(user_id):
        row = get_db().execute(
            "SELECT * FROM Users WHERE UserID = ?", (user_id,)
        ).fetchone()
        return User(row) if row else None

    # ---------- thao tác ----------
    @staticmethod
    def create(username, password, full_name, role, ref_id=None):
        """Dùng cho seed.py và cho Admin (chức năng Manage Accounts)."""
        if role not in ROLES:
            raise ValueError(f"Role không hợp lệ: {role}")
        db = get_db()
        db.execute(
            "INSERT INTO Users (Username, PasswordHash, FullName, Role, RefID) "
            "VALUES (?, ?, ?, ?, ?)",
            (username, generate_password_hash(password), full_name, role, ref_id),
        )
        db.commit()

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def change_password(self, new_password):
        db = get_db()
        db.execute(
            "UPDATE Users SET PasswordHash = ? WHERE UserID = ?",
            (generate_password_hash(new_password), self.id),
        )
        db.commit()

    def touch_last_login(self):
        db = get_db()
        db.execute(
            "UPDATE Users SET LastLoginAt = datetime('now') WHERE UserID = ?",
            (self.id,),
        )
        db.commit()


def verify_credentials(username, password):
    """Trả về (user, error_code).

    error_code: None | 'invalid' | 'locked'
    Dùng chung một thông báo cho 'sai username' và 'sai password'
    để không lộ username nào tồn tại.
    """
    user = User.find_by_username(username)
    if user is None:
        check_password_hash(_DUMMY_HASH, password)  # giữ thời gian xử lý tương đương
        return None, "invalid"
    if not user.check_password(password):
        return None, "invalid"
    if user.is_locked:
        return None, "locked"
    return user, None
