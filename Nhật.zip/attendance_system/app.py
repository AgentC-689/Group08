"""Điểm khởi chạy ứng dụng: python app.py"""
from flask import Flask, render_template, session, redirect, url_for, request

from config import Config
from db import close_db, init_db
from utils.security import csrf_token, current_user
from controllers import auth_controller, dashboard_controller


def create_app(config_overrides=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if config_overrides:
        app.config.update(config_overrides)

    app.teardown_appcontext(close_db)
    app.register_blueprint(auth_controller.bp)
    app.register_blueprint(dashboard_controller.bp)
    # Người 2-5: đăng ký blueprint của mình ở đây, ví dụ
    # app.register_blueprint(student_controller.bp)

    # Cho phép template dùng csrf_token() và current_user()
    app.jinja_env.globals["csrf_token"] = csrf_token
    app.jinja_env.globals["current_user"] = current_user

    @app.after_request
    def security_headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Cache-Control"] = "no-store"   # không cache trang sau khi logout
        return resp

    @app.errorhandler(403)
    def forbidden(_e):
        return render_template("403.html"), 403

    with app.app_context():
        init_db()
    return app


if __name__ == "__main__":
    create_app().run(debug=True)
