# Student Attendance System – Phần của Người 1 (Đăng nhập / Đăng xuất / Phân quyền)

## Chạy thử
```bash
pip install -r requirements.txt
python seed.py          # tạo 3 tài khoản mẫu
python app.py           # mở http://127.0.0.1:5000
python -m pytest tests -q
```
Tài khoản mẫu: `admin/admin123`, `gv01/lecturer123`, `sv001/student123`

## Cấu trúc (MVC theo mục 4.2 của tài liệu)
- `models/user.py` – Model: tài khoản, băm mật khẩu, xác thực
- `controllers/auth_controller.py` – Login Controller: `/login`, `/logout`, `/change-password`
- `controllers/dashboard_controller.py` – trang chủ theo vai trò (chỗ để nhóm gắn chức năng)
- `utils/security.py` – `login_required`, `role_required`, CSRF
- `templates/`, `static/` – View
- `schema.sql`, `db.py` – bảng `Users` + kết nối CSDL

## Cách các bạn khác dùng phân quyền
```python
from utils.security import role_required, current_user

@bp.route("/students")
@role_required("Admin")              # chỉ Admin
def students(): ...

@bp.route("/attendance")
@role_required("Lecturer")           # chỉ Giảng viên
def attendance():
    me = current_user()              # me.id, me.role, me.ref_id (mã GV/SV)
```
Rồi đăng ký blueprint trong `app.py` (`app.register_blueprint(...)`).
Quy tắc "SV chỉ xem dữ liệu của mình, GV chỉ xem lớp của mình" (NFR04) cần lọc thêm theo `me.ref_id` trong câu truy vấn.

## Đáp ứng yêu cầu
FR01, FR02 (đăng xuất + đổi mật khẩu), UC01 (sai mật khẩu, thiếu trường, tài khoản bị khóa),
NFR03 (băm mật khẩu, phiên hết hạn sau 30 phút, cookie HttpOnly), NFR04 (phân quyền theo vai trò).
