"""Chạy: python -m pytest tests -q   (hoặc python tests/test_auth.py)"""
import os, sys, re, tempfile, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from app import create_app
from models.user import User


@pytest.fixture()
def client():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    app = create_app({"DATABASE": path, "TESTING": True})
    with app.app_context():
        User.create("admin", "admin123", "Admin", "Admin")
        User.create("gv01", "lecturer123", "GV", "Lecturer", "GV01")
        User.create("sv001", "student123", "SV", "Student", "SV001")
        User.create("locked", "locked123", "Locked", "Student", "SV002")
        from db import get_db
        get_db().execute("UPDATE Users SET IsLocked=1 WHERE Username='locked'")
        get_db().commit()
    yield app.test_client()
    os.remove(path)


def token(client, url="/login"):
    html = client.get(url).get_data(as_text=True)
    return re.search(r'name="_csrf" value="([^"]+)"', html).group(1)


def login(client, u, p, **kw):
    return client.post("/login", data={"username": u, "password": p,
                                       "_csrf": token(client)}, **kw)


def test_login_redirects_by_role(client):
    for user, pw, dest in [("admin", "admin123", "/dashboard/admin"),
                           ("gv01", "lecturer123", "/dashboard/lecturer"),
                           ("sv001", "student123", "/dashboard/student")]:
        r = login(client, user, pw)
        assert r.status_code == 302 and r.headers["Location"].endswith(dest)
        client.post("/logout", data={"_csrf": token(client, dest)})


def test_wrong_password_and_unknown_user_same_message(client):
    a = login(client, "admin", "sai").get_data(as_text=True)
    b = login(client, "khongco", "sai").get_data(as_text=True)
    assert "Sai tên đăng nhập hoặc mật khẩu" in a and "Sai tên đăng nhập hoặc mật khẩu" in b


def test_empty_fields(client):
    assert login(client, "", "").status_code == 400


def test_locked_account(client):
    r = login(client, "locked", "locked123")
    assert r.status_code == 403 and "bị khóa" in r.get_data(as_text=True)


def test_role_protection(client):
    login(client, "sv001", "student123")
    assert client.get("/dashboard/admin").status_code == 403
    assert client.get("/dashboard/lecturer").status_code == 403
    assert client.get("/dashboard/student").status_code == 200


def test_requires_login(client):
    r = client.get("/dashboard/admin")
    assert r.status_code == 302 and "/login" in r.headers["Location"]


def test_logout_ends_session(client):
    login(client, "admin", "admin123")
    client.post("/logout", data={"_csrf": token(client, "/dashboard/admin")})
    assert client.get("/dashboard/admin").status_code == 302


def test_logout_requires_csrf(client):
    login(client, "admin", "admin123")
    assert client.post("/logout").status_code == 400


def test_change_password(client):
    login(client, "sv001", "student123")
    t = token(client, "/change-password")
    r = client.post("/change-password", data={"old_password": "student123",
        "new_password": "newpass1", "confirm_password": "newpass1", "_csrf": t})
    assert r.status_code == 302
    client.post("/logout", data={"_csrf": token(client, "/dashboard/student")})
    assert login(client, "sv001", "student123").status_code == 401
    assert login(client, "sv001", "newpass1").status_code == 302


def test_change_password_wrong_old(client):
    login(client, "sv001", "student123")
    t = token(client, "/change-password")
    r = client.post("/change-password", data={"old_password": "x",
        "new_password": "newpass1", "confirm_password": "newpass1", "_csrf": t})
    assert r.status_code == 400


def test_open_redirect_blocked(client):
    r = client.post("/login?next=https://evil.com", data={"username": "admin",
        "password": "admin123", "_csrf": token(client)})
    assert "evil.com" not in r.headers["Location"]


def test_password_is_hashed(client):
    from db import get_db
    with client.application.app_context():
        h = get_db().execute("SELECT PasswordHash FROM Users WHERE Username='admin'").fetchone()[0]
        assert h != "admin123" and ":" in h


def test_session_cookie_is_permanent_30min(client):
    login(client, "admin", "admin123")
    cookie = client.get_cookie("session")
    assert cookie is not None and cookie.expires is not None
