-- Bảng tài khoản (phần của Người 1). Người 4 sẽ ghép với các bảng
-- Students / Lecturers trong thiết kế CSDL chung của nhóm.
CREATE TABLE IF NOT EXISTS Users (
    UserID        INTEGER PRIMARY KEY AUTOINCREMENT,
    Username      TEXT    NOT NULL UNIQUE,
    PasswordHash  TEXT    NOT NULL,                 -- NFR03: lưu mật khẩu đã băm
    FullName      TEXT    NOT NULL,
    Role          TEXT    NOT NULL CHECK (Role IN ('Admin', 'Lecturer', 'Student')),
    RefID         TEXT,                             -- StudentID hoặc LecturerID tương ứng
    IsLocked      INTEGER NOT NULL DEFAULT 0,       -- UC01 3b: tài khoản bị khóa
    CreatedAt     TEXT    NOT NULL DEFAULT (datetime('now')),
    LastLoginAt   TEXT
);
